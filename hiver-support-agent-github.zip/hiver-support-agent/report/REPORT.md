# Hiver SDE Intern Take-home — AppleSupport Support Agent

## 1. Framing

The task is treated as a constrained support-routing problem: classify the customer's issue, retrieve evidence from how AppleSupport historically responded, draft a reply grounded in that evidence, and decide whether the case can be safely auto-handled or should go to a human.

**Why AppleSupport?** It has enough directly answered customer messages to support retrieval and a meaningful held-out evaluation.

## 2. System

`twcs.csv → direct customer/AppleSupport pairs → intent classifier → historical nearest-neighbour retrieval → grounded draft → risk/confidence policy`

The classifier uses word + character TF-IDF with logistic regression. Character features help with noisy Twitter text and version strings. Retrieval uses TF-IDF cosine similarity over historical customer messages. The no-API reply generator quotes the pattern of a historical AppleSupport resolution rather than inventing account-specific actions.

### Intent taxonomy

12 operational intents: battery/power, iOS update, app crash/performance, device hardware/repair, Apple Account/security, iCloud/sync/storage, music/media, connectivity/messages, billing/store/purchase, activation/setup, generic troubleshooting, other.

## 3. Baselines and current proxy results

These are **weak-label proxy metrics**, not human-validated headline results. They are included only to make development reproducible.

| System | Accuracy | Macro-F1 |
|---|---:|---:|
| Majority-label baseline | 0.417 | 0.053 |
| Word TF-IDF + logistic regression | 0.897 | 0.839 |
| Word + character TF-IDF + logistic regression | 0.922 | 0.868 |

The proxy labels come from deterministic keyword rules. They should not be presented as the final answer to the assignment.

## 4. Golden set and human agreement

`eval/create_golden.py` creates 200 examples for hand labeling. The final submission should fill `gold_intent`, `gold_action`, and `gold_reply_quality`. At least 40 examples should be independently double-labeled and Cohen's kappa reported for intent and action.

## 5. Top failure modes to inspect

The five highest-priority failure hypotheses are:

1. **Multi-issue tweets** — battery + update + performance in one message can have no single correct intent.
2. **Short/underspecified tweets** — messages such as “11.0.3” have too little evidence.
3. **Overlapping domains** — Apple Music, iCloud, and account/billing language can co-occur.
4. **Historical-reply mismatch** — a semantically similar tweet may have received a different resolution because of device, country, or account context.
5. **Escalation boundary errors** — security, billing, and repair need stricter review than ordinary troubleshooting.

For each failure, the final report should include one golden-set example, predicted output, expected output, and a concrete mitigation.

## 6. What is misleading about my headline number?

A high proxy accuracy can be misleading because the labels are produced by keyword rules rather than humans. The same rules are also close to the model's feature space, so the benchmark partly measures agreement with the labeling heuristic, not real support-intent understanding. The final headline must therefore come from the hand-labeled golden set and should be accompanied by human agreement and confidence intervals where possible.

## 7. Next week

- Expand the taxonomy only where golden-set confusion shows operational value.
- Add hard-negative retrieval evaluation and a minimum similarity threshold.
- Calibrate intent probabilities on the human-labeled set.
- Improve multi-intent routing and account-risk detection.
- Replace template drafting with an optional LLM layer while keeping retrieved evidence in the prompt.
- Add a regression suite for the top five failure modes.

## 8. Reproduction

See `README.md`. The raw dataset is not committed. The model and retrieval sample are bounded so the pipeline can be run quickly on a normal laptop.
