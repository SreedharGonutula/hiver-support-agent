# Hiver Support Agent — AppleSupport

AI customer-support agent for the Hiver SDE Intern take-home assignment.

## What it does

1. Classifies a customer message into a small operational intent taxonomy.
2. Retrieves historically similar AppleSupport cases and their real replies.
3. Drafts a grounded reply from the historical pattern.
4. Decides `auto_handle` vs `escalate` with an explicit reason.

## Reproduce locally

Place the original `twcs.csv` at `data/raw/twcs.csv`, or place the downloaded archive at `data/raw/twitter_support.zip`.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/ingest.py
python src/model.py
python eval/create_golden.py
python src/pipeline.py --text "My iPhone battery is draining very quickly after the update"
python src/baselines.py
python eval/run_eval.py
```

The first three steps are designed to fit within a short local run on a normal laptop; the retrieval index uses a bounded sample for reproducibility.

## Data

Customer Support on Twitter (Kaggle: `thoughtvector/customer-support-on-twitter`). The raw dataset is intentionally not committed to GitHub.

## Intent taxonomy

`battery_power`, `ios_update`, `app_crash_performance`, `device_hardware_repair`, `apple_id_security`, `icloud_sync_storage`, `music_media`, `connectivity_messages`, `billing_store_purchase`, `activation_setup`, `generic_troubleshooting`, `other`.

## Evaluation

`eval/create_golden.py` creates a 200-example labeling sheet. The final report should use the hand-labeled `gold_intent`, `gold_action`, and reply-quality fields, not the weak-label proxy numbers. Double-label at least 40 examples and report Cohen's kappa. The optional `eval/judge.py` provides an LLM-as-judge hook when an API key is available.

## Repository hygiene

Do **not** commit `twcs.csv`, the downloaded ZIP, virtual environments, model artifacts, or personal credentials.
