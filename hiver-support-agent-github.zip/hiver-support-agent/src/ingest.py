from pathlib import Path
import zipfile
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
ZIP_PATH = ROOT / 'data' / 'raw' / 'twitter_support.zip'
OUT_PATH = ROOT / 'data' / 'processed' / 'apple_support_pairs.csv'
BRAND = 'AppleSupport'
CHUNK = 200_000

COLS = ['tweet_id','author_id','inbound','created_at','text','response_tweet_id','in_response_to_tweet_id']

def clean_text(s: pd.Series) -> pd.Series:
    return (s.fillna('').astype(str).str.replace(r'\s+', ' ', regex=True).str.strip())

def main():
    with zipfile.ZipFile(ZIP_PATH) as z:
        with z.open('twcs.csv') as f:
            # First pass: collect AppleSupport reply IDs and metadata.
            brand_parts = []
            for chunk in pd.read_csv(f, usecols=COLS, chunksize=CHUNK):
                part = chunk[chunk['author_id'].astype(str).eq(BRAND)].copy()
                if not part.empty:
                    brand_parts.append(part)

    brand = pd.concat(brand_parts, ignore_index=True)
    parent_ids = set(pd.to_numeric(brand['in_response_to_tweet_id'], errors='coerce').dropna().astype('int64'))
    brand_ids = set(pd.to_numeric(brand['tweet_id'], errors='coerce').dropna().astype('int64'))

    # Second pass: retrieve customer messages directly answered by AppleSupport.
    customer_parts = []
    with zipfile.ZipFile(ZIP_PATH) as z:
        with z.open('twcs.csv') as f:
            for chunk in pd.read_csv(f, usecols=COLS, chunksize=CHUNK):
                ids = pd.to_numeric(chunk['tweet_id'], errors='coerce')
                hit = chunk[ids.isin(parent_ids)].copy()
                if not hit.empty:
                    customer_parts.append(hit)

    customers = pd.concat(customer_parts, ignore_index=True).drop_duplicates('tweet_id')
    customers['tweet_id'] = pd.to_numeric(customers['tweet_id'], errors='coerce').astype('Int64')
    brand['in_response_to_tweet_id'] = pd.to_numeric(brand['in_response_to_tweet_id'], errors='coerce').astype('Int64')
    pairs = customers.merge(
        brand[['tweet_id','text','created_at','in_response_to_tweet_id']].rename(columns={'tweet_id':'reply_tweet_id','text':'brand_reply','created_at':'reply_created_at','in_response_to_tweet_id':'parent_tweet_id'}),
        left_on='tweet_id', right_on='parent_tweet_id', how='inner'
    )
    pairs = pairs.rename(columns={'text':'customer_text','created_at':'customer_created_at'})
    pairs['customer_text'] = clean_text(pairs['customer_text'])
    pairs['brand_reply'] = clean_text(pairs['brand_reply'])
    pairs = pairs[pairs['customer_text'].str.len().between(5, 1000)]
    pairs = pairs[pairs['brand_reply'].str.len().between(5, 2000)]
    pairs = pairs.sort_values('customer_created_at').drop_duplicates('tweet_id')

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    pairs.to_csv(OUT_PATH, index=False)
    print(f'Brand replies: {len(brand):,}')
    print(f'Customer->brand pairs: {len(pairs):,}')
    print(f'Wrote: {OUT_PATH}')

if __name__ == '__main__':
    main()
