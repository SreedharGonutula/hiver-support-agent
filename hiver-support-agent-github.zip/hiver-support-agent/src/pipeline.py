from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import train, MODEL_PATH
import joblib
from retrieval import HistoricalRetriever
from policy import decide
from reply import draft_reply

class Agent:
    def __init__(self):
        if not MODEL_PATH.exists():
            print('Training intent model...')
            train()
        pack = joblib.load(MODEL_PATH)
        self.features, self.model = pack['features'], pack['model']
        self.retriever = HistoricalRetriever()
    def run(self, text):
        X = self.features.transform([text])
        probs = self.model.predict_proba(X)[0]
        idx = probs.argmax()
        intent = self.model.classes_[idx]
        confidence = float(probs[idx])
        examples = self.retriever.search(text, k=3)
        similarity = examples[0]['similarity'] if examples else 0.0
        policy = decide(intent, confidence, similarity)
        reply = draft_reply(intent, text, examples, policy)
        return {'intent':intent,'confidence':confidence,'decision':policy['decision'],'reason':policy['reason'],'reply':reply,'historical_examples':examples}

if __name__ == '__main__':
    import argparse, json
    p=argparse.ArgumentParser(); p.add_argument('--text',required=True); a=p.parse_args()
    print(json.dumps(Agent().run(a.text), indent=2, ensure_ascii=False))
