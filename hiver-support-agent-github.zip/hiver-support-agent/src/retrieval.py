from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'processed' / 'apple_support_pairs.csv'
ART = ROOT / 'artifacts'

class HistoricalRetriever:
    def __init__(self, max_rows=15000, seed=42):
        df = pd.read_csv(DATA, usecols=['customer_text','brand_reply'])
        if len(df) > max_rows:
            df = df.sample(max_rows, random_state=seed)
        self.df = df.reset_index(drop=True)
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), min_df=2, max_features=40000, sublinear_tf=True)
        self.X = self.vectorizer.fit_transform(self.df.customer_text)
        self.nn = NearestNeighbors(n_neighbors=5, metric='cosine', n_jobs=-1).fit(self.X)

    def search(self, text, k=3):
        q = self.vectorizer.transform([text])
        distances, idx = self.nn.kneighbors(q, n_neighbors=k)
        out=[]
        for d,i in zip(distances[0],idx[0]):
            out.append({'similarity': float(1-d), 'customer_text': self.df.iloc[i].customer_text, 'brand_reply': self.df.iloc[i].brand_reply})
        return out
