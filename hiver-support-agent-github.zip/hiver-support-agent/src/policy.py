HIGH_RISK = {'apple_id_security','billing_store_purchase','device_hardware_repair'}
SAFE = {'battery_power','ios_update','app_crash_performance','icloud_sync_storage','music_media','connectivity_messages','activation_setup','generic_troubleshooting','other'}

def decide(intent, confidence, similarity):
    reasons=[]
    if intent in HIGH_RISK:
        reasons.append('high-risk support category needs human review')
    if confidence < 0.78:
        reasons.append(f'low intent confidence ({confidence:.2f})')
    if similarity < 0.42:
        reasons.append(f'weak historical match ({similarity:.2f})')
    if reasons:
        return {'decision':'escalate','reason':'; '.join(reasons)}
    return {'decision':'auto_handle','reason':f'confidence {confidence:.2f} and historical similarity {similarity:.2f} meet thresholds'}
