from dataclasses import dataclass
import re

INTENTS = [
    'battery_power',
    'ios_update',
    'app_crash_performance',
    'device_hardware_repair',
    'apple_id_security',
    'icloud_sync_storage',
    'music_media',
    'connectivity_messages',
    'billing_store_purchase',
    'activation_setup',
    'generic_troubleshooting',
    'other',
]

PATTERNS = {
    'battery_power': [r'\bbattery\b', r'\bdrain(?:ing)?\b', r'\bcharge(?:r|ing)?\b', r'\bcharging\b', r'\bpower\b', r'\boverheat'],
    'ios_update': [r'\bios\b', r'\bupdate(?:d|ing)?\b', r'\bupgrade\b', r'\b11\.\d', r'\b12\.\d', r'\b13\.\d', r'\b14\.\d', r'\b15\.\d', r'\b16\.\d', r'\b17\.\d', r'\b18\.\d'],
    'app_crash_performance': [r'\bapp(?:s)?\b.*\bcrash', r'\bcrash(?:es|ed|ing)?\b', r'\bfreeze', r'\bfreez(?:es|ing|en)\b', r'\bslow\b', r'\bglitch', r'\bhang(?:ing)?\b', r'\bclose(?:s|d)?\b.*\bapp'],
    'device_hardware_repair': [r'\bscreen\b', r'\bdisplay\b', r'\bcrack(?:ed)?\b', r'\bbroken\b', r'\bbent\b', r'\brepair\b', r'\breplac(?:e|ement)\b', r'\bcamera\b', r'\bbutton\b', r'\bkeyboard\b'],
    'apple_id_security': [r'\bapple id\b', r'\bpassword\b', r'\bhacked\b', r'\bsecurity\b', r'\bunauthori[sz]ed\b', r'\breset\b.*\bpassword\b', r'\baccount\b.*\bsecure\b'],
    'icloud_sync_storage': [r'\bicloud\b', r'\bsync(?:ing)?\b', r'\bbackup\b', r'\bstorage\b', r'\bcontacts\b.*\bsync', r'\bphotos\b.*\bicloud'],
    'music_media': [r'\bapple music\b', r'\bmusic\b', r'\bplaylist\b', r'\bsong\b', r'\bitunes\b', r'\bpodcast\b', r'\bmovie\b'],
    'connectivity_messages': [r'\bwifi\b', r'\bwi-fi\b', r'\bbluetooth\b', r'\b4g\b', r'\b5g\b', r'\bnetwork\b', r'\bsignal\b', r'\bmessage(?:s|ing)?\b', r'\bimessage\b', r'\bsms\b', r'\bcall(?:s|ing)?\b'],
    'billing_store_purchase': [r'\bcharg(?:e|ed|ing)\b', r'\bbilling\b', r'\brefund\b', r'\bpayment\b', r'\bpaid\b', r'\bpurchase\b', r'\border\b', r'\bshipping\b', r'\bstore\b', r'\binvoice\b', r'\bsubscription\b'],
    'activation_setup': [r'\bactivat(?:e|ion|ing)\b', r'\bactivate\b', r'\bsetup\b', r'\bset up\b', r'\bnew iphone\b', r'\brestore\b', r'\btransfer\b'],
}

@dataclass
class WeakLabel:
    intent: str
    matched_terms: list[str]
    score: float

def weak_label(text: str) -> WeakLabel:
    t = str(text or '').lower()
    scores = []
    for intent, pats in PATTERNS.items():
        hits = []
        for p in pats:
            if re.search(p, t):
                hits.append(p)
        scores.append((len(hits), intent, hits))
    scores.sort(reverse=True)
    n, intent, hits = scores[0]
    if n == 0:
        return WeakLabel('generic_troubleshooting', [], 0.25)
    # Require a little evidence for generic single-keyword collisions.
    confidence = min(0.55 + 0.12 * n, 0.95)
    return WeakLabel(intent, hits, confidence)
