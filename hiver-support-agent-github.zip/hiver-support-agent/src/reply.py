import re

def clean_reply(s):
    s = re.sub(r'https?://t\.co/\S+', '', str(s))
    s = re.sub(r'@\w+', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def draft_reply(intent, text, examples, decision):
    best = clean_reply(examples[0]['brand_reply']) if examples else ''
    prefix = {
      'battery_power':'Thanks for reaching out about the battery issue.',
      'ios_update':'Thanks for reaching out about the iOS update.',
      'app_crash_performance':'Thanks for reporting the app/performance issue.',
      'device_hardware_repair':'Thanks for letting us know about the device issue.',
      'apple_id_security':'We want to help keep your Apple Account secure.',
      'icloud_sync_storage':'Thanks for reaching out about iCloud.',
      'music_media':'Thanks for reaching out about Apple Music or media.',
      'connectivity_messages':'Thanks for reporting the connectivity or messaging issue.',
      'billing_store_purchase':'Thanks for contacting us about your purchase or billing issue.',
      'activation_setup':'Thanks for reaching out about activation or setup.',
      'generic_troubleshooting':'Thanks for reaching out. We’d like to help troubleshoot this.',
      'other':'Thanks for reaching out. We’d like to help.'
    }.get(intent, 'Thanks for reaching out. We’d like to help.')
    if decision['decision']=='escalate':
        return f"{prefix} Please continue with a human support specialist so we can review the details safely."
    if best:
        return f"{prefix} A similar AppleSupport case was handled by suggesting: {best}"
    return f"{prefix} Please share your device model, iOS version, and when the issue started so we can narrow it down."
