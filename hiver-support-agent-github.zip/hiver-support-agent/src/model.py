from pathlib import Path
import joblib
import pandas as pd
from sklearn.pipeline import FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from intents import weak_label

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'processed' / 'apple_support_pairs.csv'
MODEL_DIR = ROOT / 'artifacts'
MODEL_PATH = MODEL_DIR / 'intent_model.joblib'


def train(max_rows=20000, seed=42):
    df = pd.read_csv(DATA, usecols=['customer_text','brand_reply'])
    if len(df) > max_rows:
        df = df.sample(max_rows, random_state=seed)
    labels = df['customer_text'].map(weak_label)
    df['intent'] = labels.map(lambda x: x.intent)
    X_train, X_test, y_train, y_test = train_test_split(
        df['customer_text'], df['intent'], test_size=0.2, random_state=seed, stratify=df['intent']
    )
    features = FeatureUnion([
        ('word', TfidfVectorizer(ngram_range=(1,2), min_df=2, max_features=30000, sublinear_tf=True)),
        ('char', TfidfVectorizer(analyzer='char_wb', ngram_range=(3,5), min_df=2, max_features=20000, sublinear_tf=True)),
    ])
    Xt = features.fit_transform(X_train)
    model = LogisticRegression(max_iter=500, class_weight='balanced')
    model.fit(Xt, y_train)
    pred = model.predict(features.transform(X_test))
    metrics = {'proxy_accuracy': accuracy_score(y_test, pred), 'proxy_macro_f1': f1_score(y_test, pred, average='macro')}
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump({'features': features, 'model': model, 'metrics': metrics}, MODEL_PATH)
    return metrics

if __name__ == '__main__':
    print(train())
