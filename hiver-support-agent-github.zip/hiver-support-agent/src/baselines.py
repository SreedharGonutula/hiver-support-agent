from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from intents import weak_label

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/processed/apple_support_pairs.csv'

def run(max_rows=20000, seed=42):
    df=pd.read_csv(DATA,usecols=['customer_text'])
    if len(df)>max_rows: df=df.sample(max_rows,random_state=seed)
    y=df.customer_text.map(lambda x: weak_label(x).intent)
    Xtr,Xte,ytr,yte=train_test_split(df.customer_text,y,test_size=.2,random_state=seed,stratify=y)
    maj=ytr.value_counts().idxmax(); majp=[maj]*len(yte)
    vec=TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=30000,sublinear_tf=True)
    A=vec.fit_transform(Xtr); B=vec.transform(Xte)
    lr=LogisticRegression(max_iter=500,class_weight='balanced').fit(A,ytr)
    pred=lr.predict(B)
    return {
      'majority_accuracy':accuracy_score(yte,majp),'majority_macro_f1':f1_score(yte,majp,average='macro'),
      'tfidf_accuracy':accuracy_score(yte,pred),'tfidf_macro_f1':f1_score(yte,pred,average='macro')
    }
if __name__=='__main__': print(run())
