# Decision log

1. **Brand: AppleSupport** — selected because it has a large number of directly answered customer messages, giving enough historical evidence for retrieval and evaluation.
2. **Brand identification: `author_id`** — the dataset has no explicit brand column; support brands appear as author IDs.
3. **Training evidence: direct customer→AppleSupport pairs** — use `in_response_to_tweet_id` to connect a customer message to the AppleSupport reply.
4. **Intent taxonomy: 12 small operational intents** — chosen to be actionable for routing and response drafting rather than trying to reproduce every topic.
5. **Two baselines: majority label and word-level TF-IDF logistic regression** — deliberately simple baselines make the improvement attributable and reproducible.
6. **Main classifier: word + character TF-IDF logistic regression** — character features help with misspellings, product/version strings, and short noisy tweets.
7. **Historical retrieval: TF-IDF nearest neighbours** — retrieves real AppleSupport resolutions instead of inventing unsupported troubleshooting steps.
8. **Escalation policy: confidence + similarity + risk gates** — security, billing, and hardware/repair are escalated; low-confidence or weak-match cases are also escalated.
9. **Reply generation: grounded template using the nearest historical reply** — avoids hallucinated policy or account-specific claims in the no-API baseline.
10. **Golden set: 200 stratified examples** — intended for hand labeling; labels must be completed before headline evaluation is reported.
11. **Human agreement: 40-example double label** — Cohen’s kappa is used for intent/action agreement.
12. **LLM judge is optional** — it is separated from the core pipeline so the repository remains runnable without a paid API key.
13. **Headline number caveat** — proxy metrics based on weak labels are not a substitute for the hand-labeled golden set and should never be presented as human-validated performance.
14. **Raw data exclusion** — `twcs.csv` and the ZIP are kept out of GitHub because the raw dataset is large and should be obtained from its source.
