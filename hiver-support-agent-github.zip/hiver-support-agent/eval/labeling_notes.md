# Golden-set labeling notes

Label 200 AppleSupport customer messages. Use only the customer text for intent/action labels; historical replies are shown only to assess whether the generated answer is grounded.

Intent labels:
- battery_power
- ios_update
- app_crash_performance
- device_hardware_repair
- apple_id_security
- icloud_sync_storage
- music_media
- connectivity_messages
- billing_store_purchase
- activation_setup
- generic_troubleshooting
- other

Action: `auto_handle` only when a safe, sufficiently specific response could be sent without account/payment/repair escalation; otherwise `escalate`.

For reply quality use 1–5: 1 incorrect/unsafe, 2 mostly incorrect, 3 partially useful, 4 useful, 5 highly useful and grounded.

For agreement evidence, independently double-label at least 40 examples, then compute Cohen kappa for intent and action.
