"""Optional LLM-as-judge. Requires OPENAI_API_KEY and the openai package.
The default automated evaluation does not require an API key.
"""
import os, json

def judge_one(customer, reply, intent, historical_reply=''):
    try:
        from openai import OpenAI
    except ImportError:
        raise RuntimeError('Install openai to use the optional LLM judge.')
    client=OpenAI(api_key=os.environ['OPENAI_API_KEY'])
    prompt=f"""Score this support reply from 1-5 on correctness, helpfulness, safety, and grounding in the historical support pattern.\nCustomer: {customer}\nPredicted intent: {intent}\nHistorical example: {historical_reply}\nDraft reply: {reply}\nReturn JSON with keys correctness, helpfulness, safety, grounding, overall, reason."""
    resp=client.responses.create(model=os.getenv('JUDGE_MODEL','gpt-5-mini'),input=prompt)
    text=resp.output_text
    return json.loads(text)
