from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/processed/apple_support_pairs.csv'
OUT=ROOT/'eval/golden_set.csv'
NOTES=ROOT/'eval/labeling_notes.md'

def main(n=200,seed=42):
    df=pd.read_csv(DATA,usecols=['tweet_id','customer_text','brand_reply'])
    # Approximate stratification by simple text length buckets to avoid only sampling easy/long tweets.
    df['bucket']=pd.qcut(df.customer_text.str.len().rank(method='first'),10,labels=False)
    sample=df.groupby('bucket',group_keys=False).apply(lambda x:x.sample(max(1,round(n/10)),random_state=seed)).head(n)
    sample=sample[['tweet_id','customer_text','brand_reply']].copy()
    sample['suggested_intent']=''
    sample['gold_intent']=''
    sample['gold_action']=''
    sample['gold_reply_quality']=''
    sample['labeler']=''
    sample.to_csv(OUT,index=False)
    NOTES.write_text('''# Golden-set labeling notes\n\nLabel 200 AppleSupport customer messages. Use only the customer text for intent/action labels; historical replies are shown only to assess whether the generated answer is grounded.\n\nIntent labels:\n- battery_power\n- ios_update\n- app_crash_performance\n- device_hardware_repair\n- apple_id_security\n- icloud_sync_storage\n- music_media\n- connectivity_messages\n- billing_store_purchase\n- activation_setup\n- generic_troubleshooting\n- other\n\nAction: `auto_handle` only when a safe, sufficiently specific response could be sent without account/payment/repair escalation; otherwise `escalate`.\n\nFor reply quality use 1–5: 1 incorrect/unsafe, 2 mostly incorrect, 3 partially useful, 4 useful, 5 highly useful and grounded.\n\nFor agreement evidence, independently double-label at least 40 examples, then compute Cohen kappa for intent and action.\n''')
    print(f'Wrote {len(sample)} examples to {OUT}')
if __name__=='__main__': main()
