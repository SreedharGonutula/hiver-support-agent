from pathlib import Path
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, cohen_kappa_score
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pipeline import Agent

ROOT=Path(__file__).resolve().parents[1]
GOLD=ROOT/'eval/golden_set.csv'
OUT=ROOT/'eval/results.csv'

def main():
    df=pd.read_csv(GOLD)
    if 'gold_intent' not in df or df.gold_intent.fillna('').eq('').any():
        print('Golden set is not fully labeled yet. Fill gold_intent and gold_action, then rerun.')
        return
    agent=Agent(); rows=[]
    for r in df.itertuples():
        o=agent.run(r.customer_text)
        rows.append({**o,'tweet_id':r.tweet_id,'gold_intent':r.gold_intent,'gold_action':r.gold_action,'gold_reply_quality':r.gold_reply_quality})
    out=pd.DataFrame(rows); out.to_csv(OUT,index=False)
    print('Intent accuracy:',accuracy_score(out.gold_intent,out.intent))
    print('Intent macro-F1:',f1_score(out.gold_intent,out.intent,average='macro'))
    print('Action accuracy:',accuracy_score(out.gold_action,out.decision))
    print('Saved',OUT)
    if 'labeler_2_intent' in df:
        print('Intent Cohen kappa:',cohen_kappa_score(df.gold_intent,df.labeler_2_intent))
if __name__=='__main__': main()
